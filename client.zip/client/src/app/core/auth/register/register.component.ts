import { Component, OnInit } from "@angular/core";
import { Register } from "../../models/register";

import * as _ from "underscore";
import { Router } from "@angular/router";
import { UserService } from "../../services/user.service";
@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  errors: any = {};
  // this is dependancy injection
  constructor(private router: Router, private service: UserService) {}

  ngOnInit() {
    //this.register.name = "abhinandan";
  }
  registerSubmit() {
    // register object is empty or not
    // if it is empty then every field should get a proper message.

    this.service.registerUser(this.register).subscribe(
      res => {
        console.log(JSON.stringify(this.register));
        console.log(JSON.stringify(res));
        this.router.navigate(["/login"]);
      },
      err => {
        this.errors = err.error;
        console.log(JSON.stringify(this.errors));
        console.log(JSON.stringify(err));
      }
    );
  }
}
