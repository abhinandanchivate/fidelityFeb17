import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";

const headerOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/json"
  })
};
@Injectable({
  providedIn: "root"
})
export class UserService {
  constructor(private http: HttpClient) {}
  // end point  : http://localhost:5000/api/users/register
  // post
  // error : error object we will get it over the failure
  // success: user data with id spec
  registerUser(register): Observable<any> {
    return this.http.post("/api/users/register", register, headerOptions);
    // taking traces
    //

    // 2 options
    // 1 sucess
    // 2 failure
    // @ the caller's end
  }
}
