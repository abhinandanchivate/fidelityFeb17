export class Register {
  // fieldname : type
  name: string;
  email: string;
  password: string;
  password2: string;
}
