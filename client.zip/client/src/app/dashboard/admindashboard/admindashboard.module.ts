import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { AdmindashboardRoutingModule } from "./admindashboard-routing.module";

@NgModule({
  declarations: [],
  imports: [CommonModule, AdmindashboardRoutingModule]
})
export class AdmindashboardModule {}
