import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { AdmindashboardRoutingModule } from "./admindashboard-routing.module";
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { DetailsComponent } from './details/details.component';

@NgModule({
  declarations: [AdmindashboardComponent, DetailsComponent],
  imports: [CommonModule, AdmindashboardRoutingModule]
})
export class AdmindashboardModule {}
