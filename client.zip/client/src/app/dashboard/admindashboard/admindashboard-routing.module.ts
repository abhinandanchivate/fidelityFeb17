import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AdmindashboardComponent } from "./admindashboard/admindashboard.component";
import { DetailsComponent } from "./details/details.component";

const routes: Routes = [
  {
    path: "",
    component: AdmindashboardComponent,
    pathMatch: "full"
  },
  {
    path: "details",
    component: DetailsComponent,
    pathMatch: "full"
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdmindashboardRoutingModule {}
