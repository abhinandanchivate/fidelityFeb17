package sample2;

import java.util.Scanner;

public class ExceptionMain {
	public static int div(int a , int b ) {
		int c =0;
		
		try {
			c = a/ b;
			return c;
		} catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		finally {
		System.out.println("finally expected content");
		return 100;
		}//return c;
	}
	static int counter = 0;
	public static void main(String[] args) {
		int c = 0, a =0 , b = 0;
		Scanner scanner = new Scanner(System.in);
		try {
			System.out.println("Provide the value for a ");
			a = scanner.nextInt();
			
			System.out.println("Provide the value for b ");
			b = scanner.nextInt();
			
			c = a / b;
			
			
			System.out.println(c);
		}catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			System.out.println("exception caught");
		} catch(RuntimeException e) {
			System.out.println("diff exception caught"+ e);
		}catch(Exception e) {
			System.out.println("diff exception caught"+ e);
		}catch(Throwable e) {
			System.out.println("diff exception caught"+ e);
		} 
		
		System.out.println("div result is ");
	}

}
