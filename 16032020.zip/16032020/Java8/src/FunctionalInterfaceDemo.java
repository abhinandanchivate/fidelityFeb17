
@FunctionalInterface
public interface FunctionalInterfaceDemo {

	public void display();
}
