
public class Demo1 {

	public void test(FunctionalInterfaceDemo demo) {
		demo.display();
	}
}
