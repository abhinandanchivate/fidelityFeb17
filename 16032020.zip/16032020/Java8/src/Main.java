
public class Main {

	public static void main(String[] args) {
		
		
		Demo1 demo1 = new Demo1();
		// old style
		FunctionalInterfaceDemo demo = new FunctionInterfaceDemoImpl();
		demo1.test(demo);
		
		// using anonymous object
		demo1.test(new FunctionalInterfaceDemo() {
			
			@Override
			public void display() {
				// TODO Auto-generated method stub
				System.out.println("anonymous impl");
			}
		});
		
		// using lambda
		demo1.test(()->{
			System.out.println("lambda method");
		});
	}
}
/*
 * 
 * public class annonymous class implements FunctionDemoInterface {
 * 
 * 
 * }
 * 
 * 
 */
