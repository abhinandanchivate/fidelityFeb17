
public class FunctionInterfaceDemoImpl implements FunctionalInterfaceDemo {

	@Override
	public void display() {
		// TODO Auto-generated method stub
System.out.println("mehtod impl called");
	}

}
