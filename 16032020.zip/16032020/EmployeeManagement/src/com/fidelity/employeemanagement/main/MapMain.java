package com.fidelity.employeemanagement.main;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapMain {

	public static void main(String[] args) {
	
		TreeMap< Integer, String> hashMap = new TreeMap<Integer, String>();
		
		hashMap.put(1, "abhi");
		hashMap.put(2, "abhinandan");
		hashMap.put(1, "abhi");
		hashMap.put(10, null);
		
		
		hashMap.forEach((k,v)->{
			System.out.println("key is "+k+" "+v);
		});
		
		Set<Entry<Integer, String>> entries = hashMap.entrySet();
		
		for (Iterator iterator = entries.iterator(); iterator.hasNext();) {
			Entry<Integer, String> entry = (Entry<Integer, String>) iterator.next();
			System.out.println(entry.getKey() +"  "+entry.getValue());
		}
		
		
		
	}
	
}
