package com.fidelity.employeemanagement.main;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.service.EmployeeService;
import com.fidelity.employeemanagement.service.EmployeeServiceImpl;

public class ServiceMain {

	public static void main(String[] args) {
		EmployeeService employeeService = new EmployeeServiceImpl();
	
		
		for (int i = 0; i < 11; i++) {
			Employee employee = new Employee("emp"+i, "emp"+i, "developer", 100.0f);
		// calling service
			String result = employeeService.addEmployee(employee);
			System.out.println(result);
		}
		
		Employee  employee = employeeService.getEmployeeById("emp5");
		
		if(employee == null) {
			System.out.println("employee doesnot exists");
		}
		else {
			System.out.println("employee exists"+employee);
		}
		
		Employee[] employeeNames = employeeService.getEmployeesByName("emp5");
		
		for (Employee employee2 : employeeNames) {
			if(employee2!=null)
			System.out.println(employee2);
		}
	}
}
