package com.fidelity.employeemanagement.main;

import java.util.List;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;
import com.fidelity.employeemanagement.exception.InvalidSalaryException;
import com.fidelity.employeemanagement.service.EmployeeService;
import com.fidelity.employeemanagement.service.EmployeeServiceImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = null;
		EmployeeService employeeService = new EmployeeServiceImpl();
	
	try {
		employee = new Employee("emp001", "abhi", "trainer", 1111.00f);
		String result = employeeService.addEmployee(employee);
		employee = new Employee("emp010", "abhi", "trainer", 123.00f);
		 result = employeeService.addEmployee(employee);
		 employee = new Employee("emp0100", "abhinandan", "trainer", 123000.00f);
		 result = employeeService.addEmployee(employee);
		 
//		 List<Employee> list = employeeService.getEmployeesByName("abhi");
//		list.forEach(e->System.out.println(e));
		
	} catch (InvalidSalaryException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		for (Employee e : employeeService.getEmployees()) {
			System.out.println(e);
		}
//		try {
//			Employee employee2 = employeeService.getEmployeeById("emp001");
//			System.out.println(employee2);
//		} catch (DataNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		for(Employee emp : employeeService.getEmployeesByName("emp001")) {
//			System.out.println(emp);
//		}
//		if("success".equals(employeeService.removeEmployee("emp001"))){
//			System.out.println("record deleted successfully");
//			try {
//				Employee employee2 = employeeService.getEmployeeById("emp001");
//				System.out.println(employee2);
//			} catch (DataNotFoundException e) {
//				// TODO Auto-generated catch block
//				//e.printStackTrace();
//				System.out.println("record not found");
//			}
//		}
	}

}
