package com.fidelity.employeemanagement.main;

import java.util.NavigableSet;
import java.util.TreeSet;

import com.fidelity.employeemanagement.dto.Employee;

public class TreeSetExample {

	
	public static void main(String[] args) {
		TreeSet<String> set = new TreeSet<String>();
		set.add("Abhi");
		set.add("abhi");
		set.add("Shree");
		NavigableSet<String> descendingSet = set.descendingSet();
		//set.add(null);
		descendingSet.forEach(e->System.out.println(e));
		//set.forEach(e->System.out.println(e));
	}
}
