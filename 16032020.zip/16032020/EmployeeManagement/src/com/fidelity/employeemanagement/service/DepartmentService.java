package com.fidelity.employeemanagement.service;

public interface DepartmentService {
	
	public String addDepartment(Department d);

}
