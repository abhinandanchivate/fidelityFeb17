package com.fidelity.employeemanagement.service;

import com.fidelity.employeemanagement.dto.Employee;

public class EmployeeServiceImpl2 implements EmployeeService {

	
	public String addEmployee(Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeEmployee(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee[] getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee[] getEmployeesByName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeAllEmployees() {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee getEmployeeById(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
