package com.fidelity.employeemanagement.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;
import com.fidelity.employeemanagement.utils.SalaryComparator;

public class EmployeeServiceImpl implements EmployeeService {

	TreeSet<Employee> employeeSet = new TreeSet<Employee>(new SalaryComparator());
	@Override
	public String addEmployee(Employee e) {
		// TODO Auto-generated method stub
		 try {
			 
			employeeSet.add(e);
			 return "success";
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return "fail";
		}
	}

	@Override
	public String removeEmployee(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return new ArrayList<Employee>(employeeSet);
	}

	@Override
	public List<Employee> getEmployeesByName(String firstName) {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<Employee>();
		this.employeeSet.forEach(e->{
			if(e.getEmpFirstName().equals(firstName))
			employees.add(e);
		});
		return employees;
	}

	@Override
	public void removeAllEmployees() {
		// TODO Auto-generated method stub
		
	}
	private Employee employee = null;
	@Override
	public Employee getEmployeeById(String string) throws DataNotFoundException {
		// TODO Auto-generated method stub
		
		employeeSet.forEach(e->{
			if(e.getEmpId().equals(string)) {
				employee = e;
			}
		});
		return employee;
	}
}
		
//		for (Employee employee : employeeSet) {
//			if(employee.getEmpId().equals(string)) {
//				return employee;
//			}
//			
//		}
//		return null;
//		Iterator<Employee> iterator = employeeSet.iterator();
//		
//		while (iterator.hasNext()) {
//			Employee employee = iterator.next();
//			if(employee.getEmpId().equals(string)) {
//				return employee;
//			}
//			
//		}
//		return null;
	
//	ArrayList<Employee> empList = new ArrayList();// it will hold 10 elements 
//
//	@Override
//	public String addEmployee(Employee e) {
//		// TODO Auto-generated method stub
//		try {
//			empList.add(e);
//			return "success";
//		}
//		catch(Exception exception ) {
//			System.out.println(exception);
//			
//		}
//		return "fail";
//	}
//
//	@Override
//	public String removeEmployee(String id) {
//		try {
//			boolean result = empList.remove(this.getEmployeeById(id));
//			if(result) {
//				return "success";
//			}
//		} catch (DataNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return "fail";
//	}
//
//	@Override
//	public String updateEmployee(String id, Employee e) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public ArrayList<Employee> getEmployees() {
//		// TODO Auto-generated method stub
////		Employee[] e = new Employee[empList.size()];
////		return empList.toArray(e);
//		return empList;
//	}
//
//	@Override
//	public List<Employee> getEmployeesByName(String firstName) {
//		// TODO Auto-generated method stub
//		 return empList.stream().filter(e->e.getEmpFirstName().equals(firstName)).collect(Collectors.toList());
//	}
//
//	@Override
//	public void removeAllEmployees() {
//		// TODO Auto-generated method stub
//		empList.clear();
//	}
//
//	@Override
//	public Employee getEmployeeById(String id) throws DataNotFoundException {
//		// TODO Auto-generated method stub
//		
////		for (Employee employee : empList) {
////			if(employee.getEmpId().equals(id)) {
////				return employee;
////			}
////		}
//		
//		// stream()====> will transform the content to sequential stream
//		// parallelStream() ---> will provide the parallel stream to filter or manipulation 
//		// purpose.
//		
//	Optional<Employee> employee = empList.stream().filter(e-> e.getEmpId().equals(id)).findAny();
//		if(employee.isPresent()) {
//			return employee.get();
//		}
//		else {
//			throw new DataNotFoundException("Record does not exits");
//		}
//	}
//	
////	
////
////	private Employee[] employees = new Employee[10];// array of refernce
////	private static int count = 0;
////
////	// add employee details
////	public String addEmployee(Employee e) {
////		// add employee in the array
////		// check have we reached to end limit
////		// count : count(static )
////		// size of an array : length property (arrayRefName.length)
////		if (employees.length > count) {
////			// adding work 9
////			employees[count] = e;
////			count++;
////			return "success";
////
////		} else {
////			// array full message
////            Employee[] newEmployee = new Employee[employees.length+20];
////            // copy content from old array to new Array
////            
////            System.arraycopy(employees, 0, newEmployee, 0, employees.length);
////            System.out.println(employees.length);
////            System.out.println(newEmployee.length);
////            employees = newEmployee;
////            
////            Object o = new String();
////            o = new Employee();
////            
////            
////			
////			return "full";
////		}
////		// then add the object into array
////		// if not return array is full message to caller to provide clearity.
////
////	}
////	// remove employee
////
////	public String removeEmployee(String id) {
////		for (int i = 0; i < employees.length; i++) {
////			if(employees[i].equals(id)) {
////				employees[i] = null;
////				return "success";
////			}
////		}
////		return "fail";
////	}
////
////	// update employee
////	public String updateEmployee(String id, Employee e) {
////		return null;
////	}
////
////	// get employee by id
////	public Employee getEmployeeById(String id) throws DataNotFoundException{
////		for (Employee employee : employees) {
////			if(employee.getEmpId().equals(id)) {
////				return employee;
////			}
////		}
////		return null;
////	}
////
////	// get employees
////	public Employee[] getEmployees() {
////		return employees;
////	}
////
////	// get employees on the basis of name
////	public Employee[] getEmployeesByName(String firstName) {
////		Employee[] employeesName = new Employee[10];
////		int counter = 0;
////		for (Employee employee : employees) {
////			if(firstName.equals(employee.getEmpFirstName())){
////				employeesName[counter] = employee;
////				counter++;
////			}
////		}
////		return employeesName;
////	}
////	
////	public void removeAllEmployees() {
////		employees = null;
////	}


