package com.fidelity.employeemanagement.service;

import java.util.ArrayList;
import java.util.List;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.exception.DataNotFoundException;

public interface EmployeeService {
	
	public String addEmployee(Employee e) ;

	public String removeEmployee(String id);
	public String updateEmployee(String id, Employee e) ;
	public ArrayList<Employee> getEmployees() ;
	public List<Employee> getEmployeesByName(String firstName) ;
	public void removeAllEmployees() ;

	public Employee getEmployeeById(String string) throws DataNotFoundException;

}
