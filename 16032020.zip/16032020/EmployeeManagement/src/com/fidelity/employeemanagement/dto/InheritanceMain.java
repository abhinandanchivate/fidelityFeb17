package com.fidelity.employeemanagement.dto;

import com.fidelity.employeemanagement.utils.DisplayUtils;

public class InheritanceMain {
	
	public static void main(String[] args) {
		
		Object object = new String("abhi");
		
		
	}

}
