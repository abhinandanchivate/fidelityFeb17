package com.fidelity.employeemanagement.dto;

public class Manager  extends Employee{
	
	public Manager(String empId, String empFirstName, String designation, float empSalary, String projectId,String managerId, float projectAllow) {
		this(empId,empFirstName,"","",designation,empSalary);
		this.projectAllow = projectAllow;
		this.projectID = projectId;
		this.managerId = managerId;
		System.out.println("Manager constructor1");
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return super.toString()+"Manager [managerId=" + managerId + ", projectID=" + projectID + ", projectAllow=" + projectAllow + "]";
	}
	public Manager(String empId, String empFirstName, String empLastName, String address, String designation,
			float empSalary) {
		//super();
		super(empId, empFirstName, empLastName, address, designation, empSalary);
		System.out.println("Manager constructor2");
		// TODO Auto-generated constructor stub
	}
@Override
public float calculateSalary() {
	// TODO Auto-generated method stub
	return super.calculateSalary() + projectAllow;
}
	private String managerId;
	private String projectID;
	private float projectAllow;
	public void display() {
		String res =super.empId;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public float getProjectAllow() {
		return projectAllow;
	}
	public void setProjectAllow(float projectAllow) {
		this.projectAllow = projectAllow;
	}
	public String getProjectID() {
		return projectID;
	}
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}

}
