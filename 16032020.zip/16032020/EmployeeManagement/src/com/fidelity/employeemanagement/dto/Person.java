package com.fidelity.employeemanagement.dto;

public abstract class Person {
	
	
	
	private String firstName;
	private String lastName;
	private String salution;
	private String contactNumber;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSalution() {
		return salution;
	}
	public void setSalution(String salution) {
		this.salution = salution;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	

}
