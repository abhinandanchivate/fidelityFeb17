package com.fidelity.employeemanagement.utils;

import com.fidelity.employeemanagement.dto.Employee;
import com.fidelity.employeemanagement.dto.Manager;

public class DisplayUtils {

	
	public final static int VALUE = 10;
	public static void display(Employee employee) {

		// employee details + salary calculation.
		System.out.println(employee);
// method overriding
	VALUE = 200;
			System.out.println(employee.calculateSalary());
		
	}

}
