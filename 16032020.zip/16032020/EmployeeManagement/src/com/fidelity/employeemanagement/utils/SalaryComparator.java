package com.fidelity.employeemanagement.utils;

import java.util.Comparator;

import com.fidelity.employeemanagement.dto.Employee;

public class SalaryComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee e, Employee e2) {
		// TODO Auto-generated method stub
	if(e.getEmpSalary()>e2.getEmpSalary())
	{
		return 1;
		}
	else if(e.getEmpSalary()==e2.getEmpSalary()) {
		return 0;
	}
	else {
		return -1;
	}
	}

}
