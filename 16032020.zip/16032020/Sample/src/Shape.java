
public abstract class Shape {
	public Shape() {
		// TODO Auto-generated constructor stub
		System.out.println("constructor executed");
	}
	public  void sample() {
		
		System.out.println("sample");
	}
	public abstract float area();
	public abstract float volume();
	public abstract float perimeter();
}
