
public class Main {

	
	public static void main(String[] args) {
		Shape shape  = new Square();
		
		float a = shape.area();
		
		System.out.println(a);
	}
}
