
public class ShapeImpl implements Shape {

	@Override
	public float area() {
		// TODO Auto-generated method stub
		return 30;
	}

	@Override
	public float volume() {
		// TODO Auto-generated method stub
		return 40;
	}

	@Override
	public float perimeter() {
		// TODO Auto-generated method stub
		return 50;
	}

}
