
public class Square extends Shape {

	@Override
	public void sample() {
		// TODO Auto-generated method stub
		//super.sample();
		System.out.println("square sample method");
	}
	@Override
	public float area() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public float volume() {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public float perimeter() {
		// TODO Auto-generated method stub
		return 30;
	}
	public void display() {
		System.out.println("display method called");
	}
	
}
